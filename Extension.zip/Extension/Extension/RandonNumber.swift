//
//  RandonNumber.swift
//  Extension
//
//  Created by Ravneet kaur on 2020-04-29.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit
func randomnumbers(quantity : Int) -> [CGFloat]{
    var numbers = [CGFloat]()
    for _ in 1...quantity{
        let randomnumber = CGFloat(arc4random_uniform(255))
        numbers.append(randomnumber)
    }
    return numbers
}
