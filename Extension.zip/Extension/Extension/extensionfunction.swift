//
//  extensionfunction.swift
//  Extension
//
//  Created by Ravneet kaur on 2020-04-29.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit
extension UIButton{
    func wiggles(){
        let WiggleAnim = CABasicAnimation(keyPath: "position")
        WiggleAnim.duration = 0.05
        WiggleAnim.repeatCount = 5
        WiggleAnim.autoreverses = true
        WiggleAnim.fromValue = CGPoint(x: self.center.x - 4.0, y: self.center.y)
          WiggleAnim.toValue = CGPoint(x: self.center.x + 4.0, y: self.center.y)
        layer.add(WiggleAnim, forKey: "position")
    }
    func dims(){
        UIView.animate(withDuration: 0.15, animations: {
            self.alpha = 0.75
        }) { (finished) in
            UIView.animate(withDuration: 0.15 , animations:{
              self.alpha = 1.0
            })
          
        }
    }
    func colorizes(){
        let number  = randomnumbers(quantity: 3)
        let color = UIColor(red: number[0]/255, green: number[1]/255, blue: number[2]/255, alpha: 1.0)
        UIView.animate(withDuration: 0.3){
            self.backgroundColor = color
        }
    }
}

