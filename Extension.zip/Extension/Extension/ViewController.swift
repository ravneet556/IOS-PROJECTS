//
//  ViewController.swift
//  Extension
//
//  Created by Ravneet kaur on 2020-04-29.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var colrize: UIButton!
    
    @IBOutlet weak var wiggle: UIButton!
    
    @IBOutlet weak var dim: UIButton!
    
    @IBAction func acolorize(_ sender: Any) {
        colrize.colorizes()
    }
    
    @IBAction func awiggle(_ sender: Any) {
        wiggle.wiggles()
    }
    
    @IBAction func adim(_ sender: Any) {
        dim.dims()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

