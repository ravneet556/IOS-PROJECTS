//
//  SwitchStatus.swift
//  Mutating-Potocol
//
//  Created by Ravneet kaur on 2020-05-01.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import Foundation
enum SwitchStatus : Togglable{
    case on,off
    mutating func toggle(){
        switch self{
        case .off:
            self = .on
        case .on:
            self = .off
        }
    }
}
