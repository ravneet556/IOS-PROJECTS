//
//  ViewController.swift
//  Mutating-Potocol
//
//  Created by Ravneet kaur on 2020-05-01.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var label: UILabel!
    var switchStatus : SwitchStatus = .off
    //by default it will be off
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func abtnPressed(_ sender: Any) {
        switchStatus.toggle()
        if switchStatus == .off{
            btn.setImage(UIImage(named : "offBtn")!, for: .normal)
            view.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
            label.text = " 🌚 OFF 🌚"
            label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        }
        else{
            btn.setImage(UIImage(named : "onBtn")!, for: .normal)
                       view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
                       label.text = " 🌝 ON 🌝"
                       label.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
        }
    }
}

