//
//  Toggleable.swift
//  Mutating-Potocol
//
//  Created by Ravneet kaur on 2020-05-01.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import Foundation
protocol Togglable{
    mutating func toggle()
}
