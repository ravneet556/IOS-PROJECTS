//
//  ViewController.swift
//  Protocol-Color-Magic
//
//  Created by Ravneet kaur on 2020-04-30.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController, ColorTransferDelegate{

    @IBOutlet weak var colorNameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    func userDidChoose(color: UIColor, withName colorName: String) {
        view.backgroundColor = color
        colorNameLabel.text = colorName
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ColorPickerVC"{
            let colorPicker = segue.destination as! ColorPicker
            colorPicker.delegate = self
        }
    }

}

