//
//  ColorTransferDelegate.swift
//  Protocol-Color-Magic
//
//  Created by Ravneet kaur on 2020-05-01.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit
protocol  ColorTransferDelegate {
    func userDidChoose(color : UIColor,withName colorName: String)
    
}
