//
//  ColorPicker.swift
//  Protocol-Color-Magic
//
//  Created by Ravneet kaur on 2020-05-01.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit

class ColorPicker: UIViewController {
    var delegate : ColorTransferDelegate? = nil

    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    @IBAction func ButtonPressed(sender : UIButton){
        if delegate != nil{
            delegate?.userDidChoose(color: sender.backgroundColor!, withName: sender.titleLabel!.text!)
            self.navigationController?.popViewController(animated: true)
        }
       
    }

  
}
