//
//  ViewController.swift
//  WINDOW-SHOOPER
//
//  Created by Ravneet kaur on 2020-05-07.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var hourslbl: UILabel!
    @IBOutlet weak var resultlbl: UILabel!
    @IBOutlet weak var priceTxt: CurrenyTxtField!
    @IBOutlet weak var wageTxt: CurrenyTxtField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let calBtn = UIButton(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 60))
        calBtn.backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        calBtn.setTitle("Calculate", for: .normal)
        calBtn.setTitleColor(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0), for: .normal)
        calBtn.addTarget(self, action: #selector(ViewController.calculate), for: .touchUpInside)
        priceTxt.inputAccessoryView = calBtn
        wageTxt.inputAccessoryView = calBtn
        resultlbl.isHidden = true
        hourslbl.isHidden = true
    }

    @objc func calculate(){
        if let wageTxt = wageTxt.text , let priceTxt = priceTxt.text{
            if let wage = Double(wageTxt) , let price = Double(priceTxt){
                view.endEditing(true)
                resultlbl.isHidden = false
                hourslbl.isHidden = false
                resultlbl.text = "\(Wage.getHours(forWage: wage, andprice: price))"
            }
        }
    }
    
    @IBAction func clearCalbtnPressed(_ sender: Any) {
        resultlbl.isHidden = true
        hourslbl.isHidden = true
        wageTxt.text = ""
        priceTxt.text = ""
    }
    
}

