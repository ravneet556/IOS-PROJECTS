//
//  Wage.swift
//  WINDOW-SHOOPER
//
//  Created by Ravneet kaur on 2020-05-08.
//  Copyright © 2020 Ravneet kaur. All rights reserved.
//

import Foundation
class Wage{
    
    class func getHours(forWage wage : Double,andprice price: Double)->Int{
        return Int(ceil(price/wage))
    }
}
